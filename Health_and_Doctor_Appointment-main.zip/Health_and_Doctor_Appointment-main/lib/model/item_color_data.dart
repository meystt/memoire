import 'package:flutter/material.dart';

class ItemColorData{
  final Color backgroundColor;
  final Color lineColor;
  final Color gradientColor;

  ItemColorData({this.backgroundColor, this.lineColor, this.gradientColor});
}