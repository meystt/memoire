import 'package:flutter/material.dart';

class TypeItem {
  Color color;
  String title;
  String sysval;
  String diaval;

  TypeItem(this.color, this.title, this.sysval, this.diaval);
}
