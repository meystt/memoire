import 'package:flutter/material.dart';

class Menu {
  String title;
  IconData image;
  Widget widget;
  Color color;
  Menu(this.title, this.image, this.color, this.widget);
}
